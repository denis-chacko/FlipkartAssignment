import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Script {
	static String username="";
	static String password="";
	static String product1="Realme 2 (Diamond Black, 32 GB)  (3 GB RAM)";
	static String product2="redmi note 6 pro (black, 64 gb) (4 gb ram)";
	
	
	
	WebDriver driver;

	// I have written the below code to get the path of the project
	public static String getResourcePath(String path) {
		String basePath = System.getProperty("user.dir");
		System.out.println("The path is: " + basePath + "\\" + path);
		return basePath + "\\" + path;

	}
	
	//The below code is for Explicit wait
	public  void waitForElementToBeClickable(WebElement locator,int TimeInSecs) {
		WebDriverWait wait=new WebDriverWait(this.driver,TimeInSecs );
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	// The below code is written to login to flipkart
	public  static void flipkartLogin(WebDriver driver,String username,String password) {
		// Enter email address
		 
		 driver.findElement(By.xpath("//input[@class='_2zrpKA']")).sendKeys(username);
         System.out.println("The email id has been entered.");
		
         //Enter Password
         
		 driver.findElement(By.xpath("//input[@class='_2zrpKA _3v41xv']")).sendKeys(password);
		 System.out.println("The password has been entered.");

	    //Click on Login
		driver.findElement(By.xpath("//button[@type='submit']/span")).click();
		System.out.println("The Login button has been clicked.");
		
		
	}
	
	//The below code is written to search for Product
	public static void SearchForProduct(WebDriver driver,String product) {
		
		WebElement Searchbox = driver.findElement(By.xpath("//input[@title='Search for products, brands and more']"));
		
		Searchbox.sendKeys(product+Keys.RETURN);
		System.out.println("The product has been searched: "+product);
		
	}
	
	//The below code is written to click on Product
		public static void ClickOnProduct(WebDriver driver,String product) {
			//String changedProduct = quote(product);
			WebElement firstProduct = driver.findElement(By.xpath("//*[@id='container']/div/div[3]/div[2]/div/div/div[2]/div[2]/div/div/div/a/div[3]/div[1]/div[1]"));
			firstProduct.click();
			System.out.println("The product has been clicked: "+product);
			
		}
		
		

	
	//The below code is written to Scroll and click ADD to cart button
		public static void ScrollAndClickAddToCart(WebDriver driver) {
			WebElement addToCartButton = driver.findElement(By.xpath("//button[text()='ADD TO CART']"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", addToCartButton);
			System.out.println("Scrolled to add to cart Button.");
			addToCartButton.click();
			System.out.println("The add to cart Button has been clicked.");
			
		}
		
		
		//The below code is written to click on continue shopping
		public static void clickOnContinueShopping(WebDriver driver) {
			WebElement continueShoppingButton = driver.findElement(By.xpath("//span[text()='Continue shopping']"));
			continueShoppingButton.click();
			System.out.println("The continue shopping button has been clicked.");
			
		}
		
		
		//The below code is written to switch to child window
		public static void SwitchToChild(WebDriver driver) {
		    ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(1));
		    System.out.println("Switched to: "+tabs2.get(1));
			System.out.println("Title:"+driver.getTitle());
		}
		
		
		
		
		//The Execution of the scripts starts from here
		
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", Script.getResourcePath("resources/driver/chromedriver.exe"));

		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		String url = "http://www.flipkart.com";
		
		driver.get(url);
		System.out.println("Navigated to url: "+url);
        Thread.sleep(2000);
		
		
		

		Script.flipkartLogin(driver,username,password);
		Thread.sleep(3000);
		
		
		
		
		Script.SearchForProduct(driver,product1);
		Thread.sleep(2000);
		
		Script.ClickOnProduct(driver, product1);
		Thread.sleep(3000);
		
		
		Script.SwitchToChild(driver);
	
		Script.ScrollAndClickAddToCart(driver);
		Script.clickOnContinueShopping(driver);
		
		//Second Product- Add to cart
		
		Script.SearchForProduct(driver,product2);
		Thread.sleep(2000);
		Script.ClickOnProduct(driver, product2);
		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(2));
	    
		Script.ScrollAndClickAddToCart(driver);
		
		

	}
}
